function Content(){
   return(
    <>
      <h1 className="text-center mb-4 display-5">Album example</h1>
      <p className="lead">Something short and leading about the collection below—its contents, the creator, etc. Make it short and sweet, but not too short so folks don't simply skip over it entirely.</p>
      <div className="text-center">
      <a href="" className="btn btn-primary me-3">main color</a>
      <a href="" className="btn btn-secondary">secondary color</a>
      </div>
    </>
   );
};

export default Content;